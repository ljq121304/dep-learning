import os
import json
import pandas as pd

proj_root = os.path.abspath(os.path.dirname(__file__))
comp_dir = os.path.join(proj_root, 'comparison')
csv_path = os.path.join(comp_dir, 'metrics_result.csv')

if not os.path.exists(csv_path):
    raise FileNotFoundError(f'metrics_result.csv not found at {csv_path}')

df = pd.read_csv(csv_path, encoding='utf-8')
if '平均值' in df['图像'].values:
    avg_row = df[df['图像'] == '平均值'].iloc[0]
else:
    avg_row = df.iloc[:, 1:].mean()

values = {
    'gfpgan': {'psnr': float(avg_row['GFPGAN_PSNR']), 'ssim': float(avg_row['GFPGAN_SSIM']), 'lpips': float(avg_row['GFPGAN_LPIPS'])},
    'codeformer': {'psnr': float(avg_row['CodeFormer_PSNR']), 'ssim': float(avg_row['CodeFormer_SSIM']), 'lpips': float(avg_row['CodeFormer_LPIPS'])},
    'degraded': {'psnr': float(avg_row['退化_PSNR']), 'ssim': float(avg_row['退化_SSIM']), 'lpips': float(avg_row['退化_LPIPS'])}
}

cells = []

def m(source):
    return {
        'cell_type': 'markdown',
        'metadata': {'language': 'markdown'},
        'source': source,
    }

def c(source):
    return {
        'cell_type': 'code',
        'metadata': {'language': 'python'},
        'execution_count': None,
        'outputs': [],
        'source': source,
    }

cells.append(m([
    '# 深度学习课程设计报告\n',
    '\n',
    '## 一、封面\n',
    '\n',
    '- 课程名称：图像超分与人脸修复比较\n',
    '- 设计题目：GFPGAN 与 CodeFormer 人脸修复效果对比实验\n',
    '- 姓    名：\n',
    '- 学    号：\n',
    '- 班    级：\n',
    '- 指导教师：\n',
    '- 提交日期：2026-06-29\n',
]))

cells.append(m([
    '## 二、摘要\n',
    '\n',
    '> 本报告基于 `face_restoration_experiment.py` 的运行结果，比较 GFPGAN 与 CodeFormer 两种人脸修复方法的恢复质量、定量指标和可视化效果。实验使用 `test_images/` 中 2 张测试图像，通过退化生成低质量输入图像，并分别使用 GFPGAN 与 CodeFormer 进行修复，对比恢复结果在 PSNR、SSIM、LPIPS 三项指标上的性能差异。最终结果表明：CodeFormer 在本次实验中略优于 GFPGAN，尤其在 SSIM 和 PSNR 上表现更好；但两者在 LPIPS 上差异较小，说明感知质量接近。\n',
]))

cells.append(m([
    '## 三、实验环境与依赖\n',
    '\n',
    '- Python 版本：3.11.x\n',
    '- 深度学习框架：PyTorch\n',
    '- 主要库：opencv-python、pandas、matplotlib、seaborn、Pillow、lpips、GFPGAN、basicsr、facexlib\n',
    '- 主要数据：`comparison/metrics_result.csv`、`comparison/02_metrics_bar.png`、`comparison/03_compare_test_01.png`、`comparison/03_compare_test_02.png`\n',
    '- 运行命令：`python face_restoration_experiment.py`\n',
]))

cells.append(m([
    '## 四、数据集说明与预处理\n',
    '\n',
    '- 使用 `test_images/` 中的 2 张人脸图像作为测试样本。\n',
    '- 先对原图像进行下采样、模糊与噪声退化，生成低质量输入。\n',
    '- 退化数据存储于 `degraded/`，修复结果分别保存于 `results_gfpgan/` 和 `results_codeformer/`。\n',
]))

cells.append(m([
    '## 五、方法概述\n',
    '\n',
    '### 5.1 GFPGAN\n',
    '- 采用 GFPGAN 模型进行人脸增强与修复，适合一般人像修复任务。\n',
    '- 本实验使用 GFPGANv1.3 预训练权重。\n',
    '\n',
    '### 5.2 CodeFormer\n',
    '- 使用 CodeFormer 模型进行人脸恢复，强调高保真度与细节还原。\n',
    '- 本实验使用 CodeFormer 预训练权重，并设置保真度参数 `w=0.7`。\n',
]))

cells.append(c([
    'import os\n',
    'from IPython.display import display\n',
    'import pandas as pd\n',
    'import matplotlib.pyplot as plt\n',
    'import seaborn as sns\n',
    'from PIL import Image\n',
    '\n',
    'proj_root = os.getcwd()\n',
    'comp_dir = os.path.join(proj_root, "comparison")\n',
    'print("工作目录:", proj_root)\n',
    'print("comparison 文件夹：")\n',
    'for f in sorted(os.listdir(comp_dir)):\n',
    '    print("-", f)\n',
]))

cells.append(c([
    'csv_path = os.path.join(comp_dir, "metrics_result.csv")\n',
    'df = pd.read_csv(csv_path, encoding="utf-8")\n',
    'df\n',
]))

cells.append(c([
    'avg_row = df[df["图像"] == "平均值"].iloc[0] if "平均值" in df["图像"].values else df.iloc[:, 1:].mean()\n',
    'plot_df = pd.DataFrame({\n',
    '    "PSNR": [avg_row["退化_PSNR"], avg_row["GFPGAN_PSNR"], avg_row["CodeFormer_PSNR"]],\n',
    '    "SSIM": [avg_row["退化_SSIM"], avg_row["GFPGAN_SSIM"], avg_row["CodeFormer_SSIM"]],\n',
    '    "LPIPS": [avg_row["退化_LPIPS"], avg_row["GFPGAN_LPIPS"], avg_row["CodeFormer_LPIPS"]],\n',
    '}, index=["退化","GFPGAN","CodeFormer"])\n',
    'plot_df\n',
]))

cells.append(c([
    'plt.figure(figsize=(8, 4))\n',
    'plot_df[["PSNR"]].plot(kind="bar", legend=False, ylabel="PSNR", title="平均 PSNR 对比", figsize=(4, 4));\n',
    'plt.show()\n',
    'plt.figure(figsize=(8, 4))\n',
    'plot_df[["SSIM"]].plot(kind="bar", legend=False, ylabel="SSIM", title="平均 SSIM 对比", figsize=(4, 4));\n',
    'plt.show()\n',
    'plt.figure(figsize=(8, 4))\n',
    'plot_df[["LPIPS"]].plot(kind="bar", legend=False, ylabel="LPIPS", title="平均 LPIPS 对比", figsize=(4, 4));\n',
    'plt.show()\n',
]))

cells.append(c([
    'image_paths = [\n',
    '    os.path.join(comp_dir, "01_original_vs_degraded.png"),\n',
    '    os.path.join(comp_dir, "02_metrics_bar.png"),\n',
    '    os.path.join(comp_dir, "03_compare_test_01.png"),\n',
    '    os.path.join(comp_dir, "03_compare_test_02.png"),\n',
    ']\n',
    'for p in image_paths:\n',
    '    if os.path.exists(p):\n',
    '        display(Image.open(p))\n',
    '    else:\n',
    '        print("未找到图像：", p)\n',
]))

cells.append(c([
    'import numpy as np\n',
    'def mse_image(a, b):\n',
    '    a = np.array(a).astype(np.float32)\n',
    '    b = np.array(b).astype(np.float32)\n',
    '    if a.shape != b.shape:\n',
    '        b = np.array(Image.fromarray(b.astype("uint8")).resize((a.shape[1], a.shape[0])))\n',
    '    return float(((a - b) ** 2).mean())\n',
    '\n',
    'tests = []\n',
    'for image_name in df[df["图像"] != "平均值"]["图像"]:\n',
    '    orig = os.path.join(proj_root, "test_images", image_name)\n',
    '    gfp = os.path.join(proj_root, "results_gfpgan", image_name)\n',
    '    cf = os.path.join(proj_root, "results_codeformer", image_name)\n',
    '    if os.path.exists(orig) and os.path.exists(gfp) and os.path.exists(cf):\n',
    '        mse_g = mse_image(Image.open(orig), Image.open(gfp))\n',
    '        mse_c = mse_image(Image.open(orig), Image.open(cf))\n',
    '        tests.append({"图像": image_name, "MSE_GFPGAN": mse_g, "MSE_CodeFormer": mse_c})\n',
    'df_mse = pd.DataFrame(tests)\n',
    'df_mse\n',
]))

analysis_text = f"""## 六、实验结果与分析\n\n- 退化图像与原图对比后可知，测试图像在清晰度和对比度上都显著下降。\n- 从平均指标看，GFPGAN 的平均 PSNR 为 {values['gfpgan']['psnr']:.2f}，SSIM 为 {values['gfpgan']['ssim']:.4f}，LPIPS 为 {values['gfpgan']['lpips']:.5f}。\n- CodeFormer 的平均 PSNR 为 {values['codeformer']['psnr']:.2f}，SSIM 为 {values['codeformer']['ssim']:.4f}，LPIPS 为 {values['codeformer']['lpips']:.5f}。\n- 与退化输入相比，GFPGAN 和 CodeFormer 均有明显提升，其中 CodeFormer 在 PSNR 和 SSIM 上优势更明显。\n- LPIPS 指标两者差异较小，表明在感知质量上 GFPGAN 与 CodeFormer 都呈现较接近的效果。\n\n### 结论\n\n1. CodeFormer 在本次实验中的整体恢复效果略优于 GFPGAN，适合对细节与结构保持度要求更高的场景。\n2. GFPGAN 仍是一种速度较快、综合效果稳定的修复方案，适合对效率有更高要求的应用。\n3. 若要进一步提升实验结论可靠性，应扩展测试集规模、使用更多不同质量退化类型的图像并在 GPU 环境下重复测试。\n"""
cells.append(m([analysis_text]))

cells.append(m([
    '## 七、导出与分享\n',
    '\n',
    '以下单元可以将本 notebook 导出为 HTML 文件，便于汇报与提交。\n',
]))

cells.append(c([
    'import subprocess\n',
    'try:\n',
    '    subprocess.run(["jupyter", "nbconvert", "--to", "html", "DL课程设计.ipynb", "--output", "DL课程设计_report.html"], check=True)\n',
    '    print("已导出 DL课程设计_report.html")\n',
    'except Exception as e:\n',
    '    print("导出失败：", e)\n',
]))

cells.append(m([
    '## 八、参考与附录\n',
    '\n',
    '- GFPGAN 项目：https://github.com/TencentARC/GFPGAN\n',
    '- CodeFormer 项目：https://github.com/sczhou/CodeFormer\n',
    '- 本实验结果文件存放在 `comparison/` 目录下。\n',
]))

notebook = {
    'cells': cells,
    'metadata': {
        'kernelspec': {'display_name': 'Python 3', 'language': 'python', 'name': 'python3'},
        'language_info': {'name': 'python', 'version': '3.11'},
    },
    'nbformat': 4,
    'nbformat_minor': 5,
}

path = os.path.join(proj_root, 'DL课程设计.ipynb')
with open(path, 'w', encoding='utf-8') as f:
    json.dump(notebook, f, ensure_ascii=False, indent=2)
print('已写入', path)
