import pathlib

# 创建/覆盖 version.py
p = pathlib.Path(r'C:\Users\xx\AppData\Local\Programs\Python\Python311\Lib\site-packages\basicsr\version.py')
p.write_text('__version__ = "1.4.2"\n__gitsha__ = "unknown"\n')
print('fixed version.py')

# 添加 get_device 到 misc.py（如果还没有）
misc = pathlib.Path(r'C:\Users\xx\AppData\Local\Programs\Python\Python311\Lib\site-packages\basicsr\utils\misc.py')
content = misc.read_text()
if 'def get_device' not in content:
    misc.write_text(content + '\n\ndef get_device():\n    import torch\n    return torch.device("cuda" if torch.cuda.is_available() else "cpu")\n')
    print('added get_device')
else:
    print('get_device already exists')