"""
A simple Gradio frontend for the local CodeFormer project.
Run this from the project root:
    python frontend_app.py

This script reuses the CodeFormer project code under CodeFormer/ and keeps
weights inside CodeFormer/weights. If the root weights/codeformer.pth file
already exists, it will be copied into CodeFormer/weights/CodeFormer/.
"""

import os
import shutil
import sys
import time

import cv2
import numpy as np
import torch

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
CODEFORMER_ROOT = os.path.join(ROOT_DIR, 'CodeFormer')
if CODEFORMER_ROOT not in sys.path:
    sys.path.insert(0, CODEFORMER_ROOT)

try:
    import gradio as gr
except ImportError as exc:
    raise ImportError(
        'Gradio is required to run this frontend. Install it with `pip install gradio`.'
    ) from exc

from torchvision.transforms.functional import normalize
from basicsr.archs.codeformer_arch import CodeFormer as CodeFormerArch
from basicsr.archs.rrdbnet_arch import RRDBNet
from basicsr.utils import img2tensor, tensor2img, imwrite
from basicsr.utils.download_util import load_file_from_url
from basicsr.utils.misc import get_device, gpu_is_available
from basicsr.utils.realesrgan_utils import RealESRGANer
from facelib.utils.face_restoration_helper import FaceRestoreHelper
from facelib.utils.misc import is_gray

PRETRAIN_MODEL_URLS = {
    'codeformer': 'https://github.com/sczhou/CodeFormer/releases/download/v0.1.0/codeformer.pth',
    'detection': 'https://github.com/sczhou/CodeFormer/releases/download/v0.1.0/detection_Resnet50_Final.pth',
    'parsing': 'https://github.com/sczhou/CodeFormer/releases/download/v0.1.0/parsing_parsenet.pth',
    'realesrgan': 'https://github.com/sczhou/CodeFormer/releases/download/v0.1.0/RealESRGAN_x2plus.pth',
}

LOCAL_ROOT_CODEFORMER_WEIGHT = os.path.join(ROOT_DIR, 'weights', 'codeformer.pth')
DEST_CODEFORMER_WEIGHT = os.path.join(CODEFORMER_ROOT, 'weights', 'CodeFormer', 'codeformer.pth')
DET_WEIGHT = os.path.join(CODEFORMER_ROOT, 'weights', 'facelib', 'detection_Resnet50_Final.pth')
PARSE_WEIGHT = os.path.join(CODEFORMER_ROOT, 'weights', 'facelib', 'parsing_parsenet.pth')
REALESRGAN_WEIGHT = os.path.join(CODEFORMER_ROOT, 'weights', 'realesrgan', 'RealESRGAN_x2plus.pth')
OUTPUT_DIR = os.path.join(ROOT_DIR, 'output')

os.makedirs(OUTPUT_DIR, exist_ok=True)


def ensure_weight(url, path, required=True):
    if os.path.exists(path):
        return True
    os.makedirs(os.path.dirname(path), exist_ok=True)
    print(f'  ⬇️  Downloading {os.path.basename(path)} ...')
    try:
        load_file_from_url(url=url, model_dir=os.path.dirname(path), file_name=os.path.basename(path))
        print(f'  ✅ Downloaded {os.path.basename(path)}')
        return True
    except Exception as exc:
        print(f'  ❌ Failed to download {os.path.basename(path)}: {exc}')
        if required:
            raise
        print(f'  ⚠️  Optional weight {os.path.basename(path)} missing. Related upsampling options will be disabled.')
        return False


print('Preparing CodeFormer frontend weights...')
if os.path.exists(LOCAL_ROOT_CODEFORMER_WEIGHT) and not os.path.exists(DEST_CODEFORMER_WEIGHT):
    os.makedirs(os.path.dirname(DEST_CODEFORMER_WEIGHT), exist_ok=True)
    shutil.copy2(LOCAL_ROOT_CODEFORMER_WEIGHT, DEST_CODEFORMER_WEIGHT)
    print('  ✅ Copied local weights/codeformer.pth to CodeFormer/weights/CodeFormer/codeformer.pth')

ensure_weight(PRETRAIN_MODEL_URLS['codeformer'], DEST_CODEFORMER_WEIGHT, required=True)
ensure_weight(PRETRAIN_MODEL_URLS['detection'], DET_WEIGHT, required=True)
ensure_weight(PRETRAIN_MODEL_URLS['parsing'], PARSE_WEIGHT, required=True)
realesrgan_available = ensure_weight(PRETRAIN_MODEL_URLS['realesrgan'], REALESRGAN_WEIGHT, required=False)

print('Loading models...')

device = get_device()


def set_realesrgan():
    if not realesrgan_available or not os.path.exists(REALESRGAN_WEIGHT):
        print('  ⚠️  RealESRGAN weight missing. Background/face upsampling will be disabled.')
        return None

    half = gpu_is_available()
    model = RRDBNet(
        num_in_ch=3,
        num_out_ch=3,
        num_feat=64,
        num_block=23,
        num_grow_ch=32,
        scale=2,
    )
    return RealESRGANer(
        scale=2,
        model_path=REALESRGAN_WEIGHT,
        model=model,
        tile=400,
        tile_pad=40,
        pre_pad=0,
        half=half,
    )

upsampler = set_realesrgan()

codeformer_net = CodeFormerArch(
    dim_embd=512,
    codebook_size=1024,
    n_head=8,
    n_layers=9,
    connect_list=['32', '64', '128', '256'],
).to(device)

checkpoint = torch.load(DEST_CODEFORMER_WEIGHT, map_location=device)
if 'params_ema' in checkpoint:
    checkpoint = checkpoint['params_ema']
codeformer_net.load_state_dict(checkpoint)
codeformer_net.eval()

print('  ✅ CodeFormer model ready')


def read_input_image(image):
    if isinstance(image, (str, os.PathLike)):
        return cv2.imread(str(image), cv2.IMREAD_COLOR)
    if isinstance(image, np.ndarray):
        if image.ndim == 2:
            return cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
        if image.ndim == 3 and image.shape[2] == 4:
            return cv2.cvtColor(image, cv2.COLOR_RGBA2BGR)
        if image.ndim == 3 and image.shape[2] == 3:
            return cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    raise ValueError('Unsupported input type for image; please upload a valid RGB image file.')


def log_frontend_error(exc):
    log_path = os.path.join(OUTPUT_DIR, 'frontend_error.log')
    with open(log_path, 'a', encoding='utf-8') as f:
        f.write(f'=== {time.strftime("%Y-%m-%d %H:%M:%S")} ===\n')
        f.write(str(exc) + '\n')
        import traceback

        traceback.print_exc(file=f)
        f.write('\n')
    return log_path


def inference(image, background_enhance, face_upsample, upscale, codeformer_fidelity):
    try:
        img = read_input_image(image)
        if img is None:
            raise ValueError('Failed to read the input image. Please choose a valid image file.')

        upscale = int(upscale)
        if upscale > 4:
            upscale = 4
        if upscale > 2 and max(img.shape[:2]) > 1000:
            upscale = 2
        if max(img.shape[:2]) > 1500:
            upscale = 1
            background_enhance = False
            face_upsample = False

        face_helper = FaceRestoreHelper(
            upscale,
            face_size=512,
            crop_ratio=(1, 1),
            det_model='retinaface_resnet50',
            save_ext='png',
            use_parse=True,
            device=device,
        )

        bg_upsampler = upsampler if background_enhance and upsampler is not None else None
        face_upsampler = upsampler if face_upsample and upsampler is not None else None
        if (background_enhance or face_upsample) and upsampler is None:
            print('\t⚠️  RealESRGAN unavailable; background and face upsampling disabled.')

        gray_flag = is_gray(img, threshold=5)
        face_helper.is_gray = gray_flag
        if gray_flag:
            print('\tgrayscale input: True')

        face_helper.read_image(img)
        face_helper.get_face_landmarks_5(only_center_face=False, resize=640, eye_dist_threshold=5)
        if len(face_helper.cropped_faces) == 0:
            raise ValueError('No faces detected. Please upload a clearer portrait or a closer face image.')
        face_helper.align_warp_face()

        for cropped_face in face_helper.cropped_faces:
            cropped_face_t = img2tensor(cropped_face / 255.0, bgr2rgb=True, float32=True)
            normalize(cropped_face_t, (0.5, 0.5, 0.5), (0.5, 0.5, 0.5), inplace=True)
            cropped_face_t = cropped_face_t.unsqueeze(0).to(device)

            with torch.no_grad():
                output = codeformer_net(cropped_face_t, w=codeformer_fidelity, adain=True)[0]
            restored_face = tensor2img(output, rgb2bgr=True, min_max=(-1, 1))
            face_helper.add_restored_face(restored_face)

        if bg_upsampler is not None:
            bg_img = bg_upsampler.enhance(img, outscale=upscale)[0]
        else:
            bg_img = None

        face_helper.get_inverse_affine(None)
        restored_img = face_helper.paste_faces_to_input_image(
            upsample_img=bg_img,
            draw_box=False,
            face_upsampler=face_upsampler if face_upsample else None,
        )

        save_path = os.path.join(OUTPUT_DIR, 'output.png')
        imwrite(restored_img, save_path)

        restored_img = cv2.cvtColor(restored_img, cv2.COLOR_BGR2RGB)
        return restored_img, ''
    except Exception as exc:
        log_path = log_frontend_error(exc)
        return None, f'Error: {exc}\nSee log: {log_path}'


title = 'CodeFormer Face Restoration Demo'
description = 'A local interface for CodeFormer face restoration. Upload an image and adjust the restoration settings.'
article = 'Use this demo to restore faces with CodeFormer and optional RealESRGAN upsampling.'

inputs = [
    gr.Image(type='filepath', label='Input Image'),
    gr.Checkbox(value=True, label='Background Enhance'),
    gr.Checkbox(value=True, label='Face Upsample'),
    gr.Number(value=2, label='Upscale Factor (1-4)'),
    gr.Slider(minimum=0, maximum=1, value=0.5, step=0.01, label='CodeFormer Fidelity'),
]
outputs = [
    gr.Image(type='numpy', label='Restored Image'),
    gr.Textbox(label='Error Message', interactive=False),
]


demo = gr.Interface(
    fn=inference,
    inputs=inputs,
    outputs=outputs,
    title=title,
    description=description,
    article=article,
    examples=[
        ['test_images/test_01.jpg', True, True, 2, 0.7],
        ['test_images/test_02.png', True, True, 2, 0.7],
    ],
)

demo.queue()

if __name__ == '__main__':
    demo.launch()
