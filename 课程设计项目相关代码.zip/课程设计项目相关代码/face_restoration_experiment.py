# ============================================================
#   人脸修复对比实验 — GFPGAN vs CodeFormer
#   使用方法：在 VS Code 中打开此文件，按 F5 或点击运行
# ============================================================
#
#   【操作步骤】
#   1. 先安装 Python（建议 3.9 或 3.10）
#   2. 在 VS Code 终端里运行下面的安装命令（只需要运行一次）
#   3. 准备测试照片放到 test_images/ 文件夹
#   4. 运行本脚本（按 F5）
#
# ============================================================

# 第一步：安装所有依赖（在终端运行，不是写在代码里）
# 复制下面这整行，粘贴到 VS Code 的终端（Terminal）里，回车运行：
#
# pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu && pip install gfpgan facexlib basicsr lpips scikit-image pandas matplotlib opencv-python && pip install git+https://github.com/sczhou/CodeFormer.git --depth 1
#
# 如果上面太慢，可以分开安装：
# pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu
# pip install gfpgan
# pip install facexlib basicsr
# pip install lpips scikit-image pandas matplotlib opencv-python

# ============================================================
# 第二步：下面的代码全部复制到这个 .py 文件里，直接运行
# ============================================================

import os
import sys
import time
import glob
import urllib.request

import cv2
import numpy as np
import matplotlib
matplotlib.use('Agg')  # VS Code 里不弹窗，直接保存图片
import matplotlib.pyplot as plt
import pandas as pd
import torch

print("=" * 60)
print("   人脸修复对比实验 — GFPGAN vs CodeFormer")
print("=" * 60)
print()

# ============================================================
# Step 1：创建实验所需目录
# ============================================================
print("[Step 1/17] 创建实验目录...")

folders = ['test_images', 'degraded', 'results_gfpgan', 'results_codeformer', 'weights', 'comparison']
for f in folders:
    os.makedirs(f, exist_ok=True)

print("  ✅ 目录创建完成")
print("  ⚠️  请把人脸照片放到 test_images/ 文件夹中")
print()

# ============================================================
# Step 2：（可选）自动下载示例测试图片
# ============================================================
print("[Step 2/17] 检查测试图片...")

img_files = sorted(glob.glob('test_images/*'))
img_files = [f for f in img_files if f.lower().endswith(('.jpg', '.jpeg', '.png'))]

if len(img_files) == 0:
    print("  ⚠️  test_images/ 为空，自动下载示例图片...")
    image_urls = [
        ("https://raw.githubusercontent.com/TencentARC/GFPGAN/master/inputs/whole_imgs/Blake_Lively.jpg", "test_01.jpg"),
        ("https://raw.githubusercontent.com/TencentARC/GFPGAN/master/inputs/whole_imgs/10045.png", "test_02.png"),
        ("https://raw.githubusercontent.com/TencentARC/GFPGAN/master/inputs/whole_imgs/10046.png", "test_03.png"),
    ]
    for url, filename in image_urls:
        filepath = os.path.join('test_images', filename)
        if not os.path.exists(filepath):
            try:
                urllib.request.urlretrieve(url, filepath)
                print(f"  ✅ 已下载: {filename}")
            except Exception as e:
                print(f"  ❌ 下载失败: {filename} - {e}")
        else:
            print(f"  📁 已存在: {filename}")

    img_files = sorted(glob.glob('test_images/*'))
    img_files = [f for f in img_files if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
else:
    print(f"  ✅ 找到 {len(img_files)} 张测试图片")

print()

# ============================================================
# Step 3：生成退化图像（模拟低质量人脸）
# ============================================================
print("[Step 3/17] 生成退化图像...")

def degrade_image(img_path, save_path):
    """
    对图像进行退化处理：下采样 + 高斯模糊 + 加噪
    模拟真实场景中的低质量人脸（模糊、低分辨率、噪声）
    """
    img = cv2.imread(img_path)
    h, w = img.shape[:2]

    # 1. 下采样到 1/4 再放大（模拟低分辨率）
    small = cv2.resize(img, (w // 4, h // 4), interpolation=cv2.INTER_LINEAR)
    img = cv2.resize(small, (w, h), interpolation=cv2.INTER_LINEAR)

    # 2. 高斯模糊（模拟失焦）
    img = cv2.GaussianBlur(img, (5, 5), sigmaX=1.5)

    # 3. 添加高斯噪声（模拟传感器噪声）
    noise = np.random.normal(0, 15, img.shape).astype(np.float32)
    img = np.clip(img.astype(np.float32) + noise, 0, 255).astype(np.uint8)

    cv2.imwrite(save_path, img)

for filepath in img_files:
    fname = os.path.basename(filepath)
    degraded_image = degrade_image(filepath, os.path.join('degraded', fname))
    print(f"  ✅ 退化图: {fname}")

print()

# ============================================================
# Step 4：保存原图 vs 退化图对比图
# ============================================================
print("[Step 4/17] 生成原图 vs 退化图对比...")

n = min(len(img_files), 3)
fig, axes = plt.subplots(n, 2, figsize=(8, 4 * n))
if n == 1:
    axes = axes.reshape(1, -1)

for i in range(n):
    orig = cv2.imread(img_files[i])
    degr = cv2.imread(os.path.join('degraded', os.path.basename(img_files[i])))

    axes[i, 0].imshow(cv2.cvtColor(orig, cv2.COLOR_BGR2RGB))
    axes[i, 0].set_title('Original')
    axes[i, 0].axis('off')

    axes[i, 1].imshow(cv2.cvtColor(degr, cv2.COLOR_BGR2RGB))
    axes[i, 1].set_title('Degraded')
    axes[i, 1].axis('off')

plt.suptitle('Original vs Degraded', fontsize=14)
plt.tight_layout()
plt.savefig('comparison/01_original_vs_degraded.png', dpi=150, bbox_inches='tight')
plt.close()
print("  ✅ 已保存: comparison/01_original_vs_degraded.png")
print()

# ============================================================
# Step 5：打印实验环境信息
# ============================================================
print("[Step 5/17] 实验环境信息")
print("-" * 40)
import platform
print(f"  Python: {sys.version.split()[0]}")
print(f"  PyTorch: {torch.__version__}")
print(f"  CUDA: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print(f"  GPU: {torch.cuda.get_device_name(0)}")
else:
    print(f"  Device: CPU (无GPU，速度会慢一点但完全没问题)")
print(f"  OpenCV: {cv2.__version__}")
print("-" * 40)
print()

# ============================================================
# Step 6-7：定义评价指标函数
# ============================================================
print("[Step 6/17] 初始化评价指标...")

from skimage.metrics import peak_signal_noise_ratio as psnr_ssim_psnr
from skimage.metrics import structural_similarity as ssim_func
import lpips

loss_fn = lpips.LPIPS(net='alex')
if torch.cuda.is_available():
    loss_fn = loss_fn.cuda()
print("  ✅ LPIPS 模型加载完成")


def compute_psnr(img1_path, img2_path):
    """PSNR - 峰值信噪比，越高越好"""
    img1 = cv2.imread(img1_path)
    img2 = cv2.imread(img2_path)
    img2 = cv2.resize(img2, (img1.shape[1], img1.shape[0]))
    return psnr_ssim_psnr(img1, img2, data_range=255)


def compute_ssim(img1_path, img2_path):
    """SSIM - 结构相似性，越接近1越好"""
    img1 = cv2.imread(img1_path)
    img2 = cv2.imread(img2_path)
    img2 = cv2.resize(img2, (img1.shape[1], img1.shape[0]))
    scores = []
    for i in range(3):
        score = ssim_func(img1[:, :, i], img2[:, :, i], data_range=255)
        scores.append(score)
    return np.mean(scores)


def compute_lpips(img1_path, img2_path):
    """LPIPS - 感知相似度，越低越好"""
    from PIL import Image
    import torchvision.transforms as transforms

    img1 = Image.open(img1_path).convert('RGB')
    img2 = Image.open(img2_path).convert('RGB')

    transform = transforms.Compose([
        transforms.Resize((256, 256)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
    ])

    t1 = transform(img1).unsqueeze(0)
    t2 = transform(img2).unsqueeze(0)

    if torch.cuda.is_available():
        t1 = t1.cuda()
        t2 = t2.cuda()

    with torch.no_grad():
        dist = loss_fn(t1, t2)
    return dist.item()


print()

# ============================================================
# Step 8-10：GFPGAN 修复
# ============================================================
print("[Step 8/17] 下载 GFPGAN 预训练模型...")

gfpgan_weight = 'weights/GFPGANv1.3.pth'
if not os.path.exists(gfpgan_weight):
    print("  ⬇️  下载 GFPGANv1.3.pth (约300MB)...")
    url = "https://github.com/TencentARC/GFPGAN/releases/download/v1.3.0/GFPGANv1.3.pth"
    try:
        urllib.request.urlretrieve(url, gfpgan_weight)
        print("  ✅ 下载完成")
    except Exception as e:
        print(f"  ❌ 下载失败: {e}")
        print("  💡 请手动浏览器下载，放到 weights/GFPGANv1.3.pth")
        print("  💡 下载地址: https://github.com/TencentARC/GFPGAN/releases/download/v1.3.0/GFPGANv1.3.pth")
        sys.exit(1)
else:
    print("  📁 模型已存在，跳过下载")

print()

print("[Step 9/17] 初始化 GFPGAN...")

from gfpgan import GFPGANer

restorer = GFPGANer(
    model_path=gfpgan_weight,
    upscale=2,
    arch='clean',
    channel_multiplier=2,
    bg_upsampler=None
)
print("  ✅ GFPGAN 加载完成")

print()

print("[Step 10/17] 运行 GFPGAN 人脸修复...")

degraded_files = sorted(glob.glob('degraded/*'))
gfpgan_times = []

for img_path in degraded_files:
    fname = os.path.basename(img_path)
    img = cv2.imread(img_path)

    start = time.time()
    _, _, restored_img = restorer.enhance(
        img,
        has_aligned=False,
        only_center_face=False,
        paste_back=True
    )
    elapsed = time.time() - start
    gfpgan_times.append(elapsed)

    cv2.imwrite(os.path.join('results_gfpgan', fname), restored_img)
    print(f"  ✅ {fname} | 耗时: {elapsed:.3f}s")

avg_gfpgan = sum(gfpgan_times) / len(gfpgan_times)
print(f"\n  📊 GFPGAN 平均耗时: {avg_gfpgan:.3f}s/张")
print()

# ============================================================
# Step 11-13：CodeFormer 修复
# ============================================================
print("[Step 11/17] 下载 CodeFormer 预训练模型...")

cf_weight = 'weights/codeformer.pth'
if not os.path.exists(cf_weight):
    print("  ⬇️  下载 codeformer.pth (约360MB)...")
    url = "https://github.com/sczhou/CodeFormer/releases/download/v0.1.0/codeformer.pth"
    try:
        urllib.request.urlretrieve(url, cf_weight)
        print("  ✅ 下载完成")
    except Exception as e:
        print(f"  ❌ 下载失败: {e}")
        print("  💡 请手动浏览器下载，放到 weights/codeformer.pth")
        print("  💡 下载地址: https://github.com/sczhou/CodeFormer/releases/download/v0.1.0/codeformer.pth")
        print("  💡 如果反复失败，可以跳过CodeFormer部分，只保留GFPGAN对比")
        sys.exit(1)
else:
    print("  📁 模型已存在，跳过下载")

print()

print("[Step 12/17] 初始化 CodeFormer...")

# 把 CodeFormer 目录加到 Python 搜索路径，用于导入 facelib
codeformer_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'CodeFormer')
if codeformer_dir not in sys.path:
    sys.path.insert(0, codeformer_dir)

# 强制优先使用项目目录下的 CodeFormer 版 basicsr，而不是系统里已安装的旧版本
for name in list(sys.modules):
    if name == 'basicsr' or name.startswith('basicsr.'):
        sys.modules.pop(name, None)

# 尝试导入 CodeFormer
try:
    from facelib.utils.face_restoration_helper import FaceRestoreHelper
    from basicsr.utils import img2tensor, tensor2img
    from basicsr.archs.codeformer_arch import CodeFormer as CodeFormerArch
except ImportError as e:
    print(f"  ❌ CodeFormer 导入失败: {e}")
    sys.exit(1)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# 直接使用项目内置的 CodeFormer 实现，避免被系统中旧版 basicsr 的注册表影响
codeformer_net = CodeFormerArch(
    dim_embd=512,
    codebook_size=1024,
    n_head=8,
    n_layers=9,
    connect_list=['32', '64', '128', '256']
).to(device)

ckpt = torch.load(cf_weight, map_location=device)['params_ema']
codeformer_net.load_state_dict(ckpt)
codeformer_net.eval()

face_helper = FaceRestoreHelper(
    upscale_factor=2,
    face_size=512,
    crop_ratio=(1, 1),
    det_model='retinaface_resnet50',
    save_ext='png',
    use_parse=True,
    device=device
)

print("  ✅ CodeFormer 加载完成")

print()

print("[Step 13/17] 运行 CodeFormer 人脸修复...")

w = 0.7  # 保真度权重，0~1，越大越接近原图
codeformer_times = []

for img_path in degraded_files:
    fname = os.path.basename(img_path)
    img = cv2.imread(img_path)

    start = time.time()

    face_helper.clean_all()
    face_helper.read_image(img)
    face_helper.get_face_landmarks_5(only_center_face=False, resize=640, eye_dist_threshold=5)
    face_helper.align_warp_face()

    for cropped_face in face_helper.cropped_faces:
        import torchvision
        face_t = img2tensor(cropped_face / 255., bgr2rgb=True, float32=True)
        torchvision.transforms.functional.normalize(face_t, [0.5, 0.5, 0.5], [0.5, 0.5, 0.5], inplace=True)
        face_t = face_t.unsqueeze(0).to(device)

        with torch.no_grad():
            output = codeformer_net(face_t, w=w, adain=True)[0]
        restored_face = tensor2img(output, rgb2bgr=True, min_max=(-1, 1))
        face_helper.add_restored_face(restored_face)

    face_helper.get_inverse_affine(None)
    result_img = face_helper.paste_faces_to_input_image()

    elapsed = time.time() - start
    codeformer_times.append(elapsed)

    cv2.imwrite(os.path.join('results_codeformer', fname), result_img)
    print(f"  ✅ {fname} | 耗时: {elapsed:.3f}s")

avg_cf = sum(codeformer_times) / len(codeformer_times)
print(f"\n  📊 CodeFormer 平均耗时: {avg_cf:.3f}s/张")
print()

# ============================================================
# Step 14：计算所有定量指标
# ============================================================
print("[Step 14/17] 计算定量评估指标...")

test_files = sorted(glob.glob('test_images/*'))
test_files = [f for f in test_files if f.lower().endswith(('.jpg', '.jpeg', '.png'))]

records = []

for filepath in test_files:
    fname = os.path.basename(filepath)
    gt_path = filepath
    degraded_path = os.path.join('degraded', fname)
    gfpgan_path = os.path.join('results_gfpgan', fname)
    cf_path = os.path.join('results_codeformer', fname)

    print(f"  计算: {fname}")

    # 退化图指标
    psnr_d = compute_psnr(gt_path, degraded_path)
    ssim_d = compute_ssim(gt_path, degraded_path)
    lpips_d = compute_lpips(gt_path, degraded_path)

    # GFPGAN指标
    psnr_g = compute_psnr(gt_path, gfpgan_path)
    ssim_g = compute_ssim(gt_path, gfpgan_path)
    lpips_g = compute_lpips(gt_path, gfpgan_path)

    # CodeFormer指标
    psnr_c = compute_psnr(gt_path, cf_path)
    ssim_c = compute_ssim(gt_path, cf_path)
    lpips_c = compute_lpips(gt_path, cf_path)

    records.append({
        '图像': fname,
        '退化_PSNR': round(psnr_d, 2),
        '退化_SSIM': round(ssim_d, 4),
        '退化_LPIPS': round(lpips_d, 4),
        'GFPGAN_PSNR': round(psnr_g, 2),
        'GFPGAN_SSIM': round(ssim_g, 4),
        'GFPGAN_LPIPS': round(lpips_g, 4),
        'CodeFormer_PSNR': round(psnr_c, 2),
        'CodeFormer_SSIM': round(ssim_c, 4),
        'CodeFormer_LPIPS': round(lpips_c, 4),
    })

df = pd.DataFrame(records)

# 加上平均值
mean_row = df.mean(numeric_only=True)
mean_row['图像'] = '平均值'
df = pd.concat([df, pd.DataFrame([mean_row])], ignore_index=True)

print("\n📊 指标结果汇总:")
print("-" * 100)
print(df.to_string(index=False))

df.to_csv('comparison/metrics_result.csv', index=False, encoding='utf-8-sig')
print("\n  ✅ 已保存: comparison/metrics_result.csv")
print()

# ============================================================
# Step 15：绘制指标柱状图
# ============================================================
print("[Step 15/17] 绘制指标柱状图...")

mean_data = df[df['图像'] == '平均值'].iloc[0]
methods = ['Degraded\n(Baseline)', 'GFPGAN', 'CodeFormer']
colors = ['#999999', '#4C72B0', '#DD8452']

fig, axes = plt.subplots(1, 3, figsize=(15, 5))

# PSNR
psnr_vals = [mean_data['退化_PSNR'], mean_data['GFPGAN_PSNR'], mean_data['CodeFormer_PSNR']]
axes[0].bar(methods, psnr_vals, color=colors)
axes[0].set_title('PSNR (Higher is Better)', fontsize=13)
axes[0].set_ylabel('PSNR (dB)')
for i, v in enumerate(psnr_vals):
    axes[0].text(i, v + 0.3, f'{v:.2f}', ha='center', fontsize=11)

# SSIM
ssim_vals = [mean_data['退化_SSIM'], mean_data['GFPGAN_SSIM'], mean_data['CodeFormer_SSIM']]
axes[1].bar(methods, ssim_vals, color=colors)
axes[1].set_title('SSIM (Closer to 1 is Better)', fontsize=13)
axes[1].set_ylabel('SSIM')
for i, v in enumerate(ssim_vals):
    axes[1].text(i, v + 0.01, f'{v:.4f}', ha='center', fontsize=11)

# LPIPS
lpips_vals = [mean_data['退化_LPIPS'], mean_data['GFPGAN_LPIPS'], mean_data['CodeFormer_LPIPS']]
axes[2].bar(methods, lpips_vals, color=colors)
axes[2].set_title('LPIPS (Lower is Better)', fontsize=13)
axes[2].set_ylabel('LPIPS')
for i, v in enumerate(lpips_vals):
    axes[2].text(i, v + 0.005, f'{v:.4f}', ha='center', fontsize=11)

plt.suptitle('Metrics Comparison (Average)', fontsize=15, fontweight='bold')
plt.tight_layout()
plt.savefig('comparison/02_metrics_bar.png', dpi=200, bbox_inches='tight')
plt.close()
print("  ✅ 已保存: comparison/02_metrics_bar.png")
print()

# ============================================================
# Step 16：生成四宫格对比图
# ============================================================
print("[Step 16/17] 生成四宫格对比图...")

for filepath in test_files:
    fname = os.path.basename(filepath)
    orig = cv2.imread(filepath)
    degr = cv2.imread(os.path.join('degraded', fname))
    gfp = cv2.imread(os.path.join('results_gfpgan', fname))
    cf = cv2.imread(os.path.join('results_codeformer', fname))

    fig, axes = plt.subplots(1, 4, figsize=(16, 4))
    imgs = [orig, degr, gfp, cf]
    titles = ['Original', 'Degraded', 'GFPGAN', f'CodeFormer (w=0.7)']

    for ax, img, title in zip(axes, imgs, titles):
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        ax.imshow(img_rgb)
        ax.set_title(title, fontsize=12)
        ax.axis('off')

    plt.suptitle(f'Comparison: {fname}', fontsize=14, fontweight='bold')
    plt.tight_layout()
    save_name = os.path.join('comparison', f'03_compare_{os.path.splitext(fname)[0]}.png')
    plt.savefig(save_name, dpi=200, bbox_inches='tight')
    plt.close()
    print(f"  ✅ {save_name}")

print()

# ============================================================
# Step 17：速度对比
# ============================================================
print("[Step 17/17] 推理速度对比...")
print(f"  退化图像: 0.001s/张 (无需推理)")
print(f"  GFPGAN:   {avg_gfpgan:.3f}s/张")
print(f"  CodeFormer: {avg_cf:.3f}s/张")

speed_df = pd.DataFrame({
    'Method': ['Degraded (Baseline)', 'GFPGAN', 'CodeFormer'],
    'Avg Time (s)': [0.001, avg_gfpgan, avg_cf]
})
speed_df.to_csv('comparison/speed_result.csv', index=False, encoding='utf-8-sig')
print()

# ============================================================
# 全部完成！
# ============================================================
print("=" * 60)
print("   🎉 全部实验完成！")
print("=" * 60)
print()
print("  📂 结果文件都在 comparison/ 文件夹里：")
print("     ├── metrics_result.csv          ← 指标数据表格")
print("     ├── 02_metrics_bar.png          ← 柱状图")
print("     ├── speed_result.csv            ← 速度对比")
print("     ├── 01_original_vs_degraded.png ← 原图vs退化图")
print("     ├── 03_compare_test_01.png     ← 四宫格对比图")
print("     └── ...")
print()
print("  💡 把这些图片和数据表格复制到你的报告里就行了！")
